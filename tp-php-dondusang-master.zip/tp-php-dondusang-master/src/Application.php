<?php

namespace Ynov;

class Application
{
    public function bootstrap()
    {
        print "<script>alert('Ça marche.');</script>";
    }
}
